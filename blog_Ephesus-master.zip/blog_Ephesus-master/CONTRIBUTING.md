# Become a contributor

1. Fork
2. Create new branch, representing the changes
3. Make changes, ensure it's working
4. Push your own repo
5. Create PR, describe your changes
6. Thank You
