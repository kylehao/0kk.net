﻿//播放列表
var music_list =[
{"id":"1","name":"JUST-M~1.MP3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/JUST-M~1.MP3","images":"img/a1.jpg"},
{"id":"2","name":"Just-不怕.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/Just-不怕.mp3","images":"img/a2.jpg"},
{"id":"3","name":"JustinTimberlake-CAN'TSTOPTHEFEELING!.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/JustinTimberlake-CAN'TSTOPTHEFEELING!.mp3","images":"img/a3.jpg"},
{"id":"4","name":"Kis-My-Ft2-Gravity.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/Kis-My-Ft2-Gravity.mp3","images":"img/a4.jpg"},
{"id":"5","name":"LosBunkers-AlFinalDeEsteViajeEnLaVida.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/LosBunkers-AlFinalDeEsteViajeEnLaVida.mp3","images":"img/a5.jpg"},
{"id":"6","name":"MIC男团-天使在身边.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/MIC男团-天使在身边.mp3","images":"img/a1.jpg"},
{"id":"7","name":"Postmen-想你了(MissYou).mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/Postmen-想你了(MissYou).mp3","images":"img/a2.jpg"},
{"id":"8","name":"Rain-假装.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/Rain-假装.mp3","images":"img/a3.jpg"},
{"id":"9","name":"Rain、Ravi-克拉恋人.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/Rain、Ravi-克拉恋人.mp3","images":"img/a4.jpg"},
{"id":"10","name":"Salt-N-Pepa-Shoop.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/Salt-N-Pepa-Shoop.mp3","images":"img/a5.jpg"},
{"id":"11","name":"Sara-微小的失落.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/Sara-微小的失落.mp3","images":"img/a1.jpg"},
{"id":"12","name":"ScarlettJohansson-TrustinMe.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/ScarlettJohansson-TrustinMe.mp3","images":"img/a2.jpg"},
{"id":"13","name":"Shakira-TryEverything.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/Shakira-TryEverything.mp3","images":"img/a3.jpg"},
{"id":"14","name":"SPICA-因为你.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/SPICA-因为你.mp3","images":"img/a4.jpg"},
{"id":"15","name":"SunnyHill-SayILoveYou.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/SunnyHill-SayILoveYou.mp3","images":"img/a5.jpg"},
{"id":"16","name":"TFBOYS-未来的进击.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/TFBOYS-未来的进击.mp3","images":"img/a1.jpg"},
{"id":"17","name":"Wable-???.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/Wable-???.mp3","images":"img/a2.jpg"},
{"id":"18","name":"WizKhalifa、CharliePuth-SeeYouAgain.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/WizKhalifa、CharliePuth-SeeYouAgain.mp3","images":"img/a3.jpg"},
{"id":"19","name":"Younha-Sunflower.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/Younha-Sunflower.mp3","images":"img/a4.jpg"},
{"id":"20","name":"Younha-祈祷.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/Younha-祈祷.mp3","images":"img/a5.jpg"},
{"id":"21","name":"中央少年广播合唱团、李烨琳-我是中国的孩子.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/中央少年广播合唱团、李烨琳-我是中国的孩子.mp3","images":"img/a1.jpg"},
{"id":"22","name":"井柏然、白百何-明天你会在哪里.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/井柏然、白百何-明天你会在哪里.mp3","images":"img/a2.jpg"},
{"id":"23","name":"任容萱-爱不爱都寂寞.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/任容萱-爱不爱都寂寞.mp3","images":"img/a3.jpg"},
{"id":"24","name":"任贤齐、王子文-时光诛仙.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/任贤齐、王子文-时光诛仙.mp3","images":"img/a4.jpg"},
{"id":"25","name":"何晟铭-幸福的方向.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/何晟铭-幸福的方向.mp3","images":"img/a5.jpg"},
{"id":"26","name":"何洁-不可能的人.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/何洁-不可能的人.mp3","images":"img/a1.jpg"},
{"id":"27","name":"何雁诗-TheOnlyOne.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/何雁诗-TheOnlyOne.mp3","images":"img/a2.jpg"},
{"id":"28","name":"何雁诗-我和你.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/何雁诗-我和你.mp3","images":"img/a3.jpg"},
{"id":"29","name":"何雁诗-最真心一对.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/何雁诗-最真心一对.mp3","images":"img/a4.jpg"},
{"id":"30","name":"何雁诗-爱情食物链.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/何雁诗-爱情食物链.mp3","images":"img/a5.jpg"},
{"id":"31","name":"佟丽娅-管你爱不爱.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/佟丽娅-管你爱不爱.mp3","images":"img/a1.jpg"},
{"id":"32","name":"侧田-同步.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/侧田-同步.mp3","images":"img/a2.jpg"},
{"id":"33","name":"侧田、李思捷-出口.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/侧田、李思捷-出口.mp3","images":"img/a3.jpg"},
{"id":"34","name":"信-远得要命的爱情.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/信-远得要命的爱情.mp3","images":"img/a4.jpg"},
{"id":"35","name":"信乐团-离歌.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/信乐团-离歌.mp3","images":"img/a5.jpg"},
{"id":"36","name":"关诗敏-别说.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/关诗敏-别说.mp3","images":"img/a1.jpg"},
{"id":"37","name":"凤凰传奇-一路惊喜.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/凤凰传奇-一路惊喜.mp3","images":"img/a2.jpg"},
{"id":"38","name":"刘一祯-梦一场.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/刘一祯-梦一场.mp3","images":"img/a3.jpg"},
{"id":"39","name":"刘伟男-如果能再见.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/刘伟男-如果能再见.mp3","images":"img/a4.jpg"},
{"id":"40","name":"刘力扬-属于你的歌.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/刘力扬-属于你的歌.mp3","images":"img/a5.jpg"},
{"id":"41","name":"刘庭羽-勿忘我.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/刘庭羽-勿忘我.mp3","images":"img/a1.jpg"},
{"id":"42","name":"刘德华-原谅我.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/刘德华-原谅我.mp3","images":"img/a2.jpg"},
{"id":"43","name":"刘德华、李宇春-恭喜发财2016.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/刘德华、李宇春-恭喜发财2016.mp3","images":"img/a3.jpg"},
{"id":"44","name":"刘德华、黄晓明、沈腾-笑一笑.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/刘德华、黄晓明、沈腾-笑一笑.mp3","images":"img/a4.jpg"},
{"id":"45","name":"刘恺威-抓不住的温柔.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/刘恺威-抓不住的温柔.mp3","images":"img/a5.jpg"},
{"id":"46","name":"刘恺威-无终.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/刘恺威-无终.mp3","images":"img/a1.jpg"},
{"id":"47","name":"刘惜君-直到那一天.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/刘惜君-直到那一天.mp3","images":"img/a2.jpg"},
{"id":"48","name":"刘欢、吉克隽逸-奋不顾身.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/刘欢、吉克隽逸-奋不顾身.mp3","images":"img/a3.jpg"},
{"id":"49","name":"刘涛-红颜旧.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/刘涛-红颜旧.mp3","images":"img/a4.jpg"},
{"id":"50","name":"刘涛-错爱.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/刘涛-错爱.mp3","images":"img/a5.jpg"},
{"id":"51","name":"刘珂、陈冰-告别昨天.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/刘珂、陈冰-告别昨天.mp3","images":"img/a1.jpg"},
{"id":"52","name":"刘端端-疯狂爱.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/刘端端-疯狂爱.mp3","images":"img/a2.jpg"},
{"id":"53","name":"华晨宇-火星情报局.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/华晨宇-火星情报局.mp3","images":"img/a3.jpg"},
{"id":"54","name":"南征北战-萨瓦迪卡.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/南征北战-萨瓦迪卡.mp3","images":"img/a4.jpg"},
{"id":"55","name":"印子月-落空.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/印子月-落空.mp3","images":"img/a5.jpg"},
{"id":"56","name":"原子霏-繁花.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/原子霏-繁花.mp3","images":"img/a1.jpg"},
{"id":"57","name":"原子霏-芈月传.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/原子霏-芈月传.mp3","images":"img/a2.jpg"},
{"id":"58","name":"反光镜-来到你身边.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/反光镜-来到你身边.mp3","images":"img/a3.jpg"},
{"id":"59","name":"吉克隽逸-幸福加油.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/吉克隽逸-幸福加油.mp3","images":"img/a4.jpg"},
{"id":"60","name":"吉克隽逸-我是女王.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/吉克隽逸-我是女王.mp3","images":"img/a5.jpg"},
{"id":"61","name":"吴亦凡-从此以后.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/吴亦凡-从此以后.mp3","images":"img/a1.jpg"},
{"id":"62","name":"吴亦凡-花房姑娘.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/吴亦凡-花房姑娘.mp3","images":"img/a2.jpg"},
{"id":"63","name":"吴婧-浮生梦.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/吴婧-浮生梦.mp3","images":"img/a3.jpg"},
{"id":"64","name":"吴若希-完美的生活.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/吴若希-完美的生活.mp3","images":"img/a4.jpg"},
{"id":"65","name":"吴若希-我们都受伤.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/吴若希-我们都受伤.mp3","images":"img/a5.jpg"},
{"id":"66","name":"吴若希-美好的时光.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/吴若希-美好的时光.mp3","images":"img/a1.jpg"},
{"id":"67","name":"吴莫愁-舞底线.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/吴莫愁-舞底线.mp3","images":"img/a2.jpg"},
{"id":"68","name":"周杰伦、aMEI-不该.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/周杰伦、aMEI-不该.mp3","images":"img/a3.jpg"},
{"id":"69","name":"周笔畅-我选择喜欢你.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/周笔畅-我选择喜欢你.mp3","images":"img/a4.jpg"},
{"id":"70","name":"周笔畅-新步步惊心.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/周笔畅-新步步惊心.mp3","images":"img/a5.jpg"},
{"id":"71","name":"周笔畅-片羽时光.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/周笔畅-片羽时光.mp3","images":"img/a1.jpg"},
{"id":"72","name":"周笔畅-若不是那次夜空.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/周笔畅-若不是那次夜空.mp3","images":"img/a2.jpg"},
{"id":"73","name":"周诗雅-爱难抗拒.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/周诗雅-爱难抗拒.mp3","images":"img/a3.jpg"},
{"id":"74","name":"周迅-幸福的开关.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/周迅-幸福的开关.mp3","images":"img/a4.jpg"},
{"id":"75","name":"和汇慧-两个人一支烟.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/和汇慧-两个人一支烟.mp3","images":"img/a5.jpg"},
{"id":"76","name":"和汇慧-记忆中的未来.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/和汇慧-记忆中的未来.mp3","images":"img/a1.jpg"},
{"id":"77","name":"品冠-一个人不一定就不快乐.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/品冠-一个人不一定就不快乐.mp3","images":"img/a2.jpg"},
{"id":"78","name":"品冠-我一个人记得就好.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/品冠-我一个人记得就好.mp3","images":"img/a3.jpg"},
{"id":"79","name":"品冠-还好有你.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/品冠-还好有你.mp3","images":"img/a4.jpg"},
{"id":"80","name":"唐嫣-好久不见.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/唐嫣-好久不见.mp3","images":"img/a5.jpg"},
{"id":"81","name":"唐禹哲-寻找爱的冒险.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/唐禹哲-寻找爱的冒险.mp3","images":"img/a1.jpg"},
{"id":"82","name":"圈住那个9、不才-飞鸟和她.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/圈住那个9、不才-飞鸟和她.mp3","images":"img/a2.jpg"},
{"id":"83","name":"圭贤-直到抵达你的星球.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/圭贤-直到抵达你的星球.mp3","images":"img/a3.jpg"},
{"id":"84","name":"多亮-诉衷情.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/多亮-诉衷情.mp3","images":"img/a4.jpg"},
{"id":"85","name":"好妹妹乐队-不说再见.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/好妹妹乐队-不说再见.mp3","images":"img/a5.jpg"},
{"id":"86","name":"好妹妹乐队-门.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/好妹妹乐队-门.mp3","images":"img/a1.jpg"},
{"id":"87","name":"姚笛-Angel.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/姚笛-Angel.mp3","images":"img/a2.jpg"},
{"id":"88","name":"孙子涵-回忆那么伤.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/孙子涵-回忆那么伤.mp3","images":"img/a3.jpg"},
{"id":"89","name":"孙楠-一起奔放.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/孙楠-一起奔放.mp3","images":"img/a4.jpg"},
{"id":"90","name":"孙楠-大秧歌序曲.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/孙楠-大秧歌序曲.mp3","images":"img/a5.jpg"},
{"id":"91","name":"孙楠、吴京-你来不来.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/孙楠、吴京-你来不来.mp3","images":"img/a1.jpg"},
{"id":"92","name":"孙燕姿-在,也不见.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/孙燕姿-在,也不见.mp3","images":"img/a2.jpg"},
{"id":"93","name":"孙铭宇-英雄泪.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/孙铭宇-英雄泪.mp3","images":"img/a3.jpg"},
{"id":"94","name":"宁桓宇-替你爱我.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/宁桓宇-替你爱我.mp3","images":"img/a4.jpg"},
{"id":"95","name":"宋冬野-万物生长.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/宋冬野-万物生长.mp3","images":"img/a5.jpg"},
{"id":"96","name":"宋小宝、岳云鹏-往事只能回味.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/宋小宝、岳云鹏-往事只能回味.mp3","images":"img/a1.jpg"},
{"id":"97","name":"宋茜-IBelieve.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/宋茜-IBelieve.mp3","images":"img/a2.jpg"},
{"id":"98","name":"宋茜-星星泪.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/宋茜-星星泪.mp3","images":"img/a3.jpg"},
{"id":"99","name":"宥胜-昨日.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/宥胜-昨日.mp3","images":"img/a4.jpg"},
{"id":"100","name":"小柯-对不起.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/小柯-对不起.mp3","images":"img/a5.jpg"},
{"id":"101","name":"小沈阳-八戒八戒.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/小沈阳-八戒八戒.mp3","images":"img/a1.jpg"},
{"id":"102","name":"小爱的妈-神通.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/小爱的妈-神通.mp3","images":"img/a2.jpg"},
{"id":"103","name":"小野丽莎-等待你出现.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/小野丽莎-等待你出现.mp3","images":"img/a3.jpg"},
{"id":"104","name":"尚雯婕-为爱归来.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/尚雯婕-为爱归来.mp3","images":"img/a4.jpg"},
{"id":"105","name":"尚雯婕-侠客行.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/尚雯婕-侠客行.mp3","images":"img/a5.jpg"},
{"id":"106","name":"尚雯婕-时间的力量.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/尚雯婕-时间的力量.mp3","images":"img/a1.jpg"},
{"id":"107","name":"尹美莱-ALWAYS.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/尹美莱-ALWAYS.mp3","images":"img/a2.jpg"},
{"id":"108","name":"崔子格-匆匆.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/崔子格-匆匆.mp3","images":"img/a3.jpg"},
{"id":"109","name":"崔子格-可念不可说.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/崔子格-可念不可说.mp3","images":"img/a4.jpg"},
{"id":"110","name":"崔子格、盛一伦-可念不可说.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/崔子格、盛一伦-可念不可说.mp3","images":"img/a5.jpg"},
{"id":"111","name":"崔恕、赵佳霖-长安乱.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/崔恕、赵佳霖-长安乱.mp3","images":"img/a1.jpg"},
{"id":"112","name":"帕尔哈提-忘了她.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/帕尔哈提-忘了她.mp3","images":"img/a2.jpg"},
{"id":"113","name":"常石磊-这里的黎明静悄悄.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/常石磊-这里的黎明静悄悄.mp3","images":"img/a3.jpg"},
{"id":"114","name":"平原綾香-明日.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/平原綾香-明日.mp3","images":"img/a4.jpg"},
{"id":"115","name":"张一山、张承、葛铮-落日谣.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张一山、张承、葛铮-落日谣.mp3","images":"img/a5.jpg"},
{"id":"116","name":"张一山、葛铮、张承-打屁歌.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张一山、葛铮、张承-打屁歌.mp3","images":"img/a1.jpg"},
{"id":"117","name":"张丹峰-地老天荒.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张丹峰-地老天荒.mp3","images":"img/a2.jpg"},
{"id":"118","name":"张信哲-IBelieve.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张信哲-IBelieve.mp3","images":"img/a3.jpg"},
{"id":"119","name":"张信哲-焚情.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张信哲-焚情.mp3","images":"img/a4.jpg"},
{"id":"120","name":"张含韵-相思赋.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张含韵-相思赋.mp3","images":"img/a5.jpg"},
{"id":"121","name":"张含韵-问别.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张含韵-问别.mp3","images":"img/a1.jpg"},
{"id":"122","name":"张家辉-你是我心爱的姑娘.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张家辉-你是我心爱的姑娘.mp3","images":"img/a2.jpg"},
{"id":"123","name":"张惠妹-灵魂尽头.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张惠妹-灵魂尽头.mp3","images":"img/a3.jpg"},
{"id":"124","name":"张曼玉-如果没了你.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张曼玉-如果没了你.mp3","images":"img/a4.jpg"},
{"id":"125","name":"张杰-LostintheStars.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张杰-LostintheStars.mp3","images":"img/a5.jpg"},
{"id":"126","name":"张杰-娑婆世界.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张杰-娑婆世界.mp3","images":"img/a1.jpg"},
{"id":"127","name":"张杰、莫文蔚-一念之间.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张杰、莫文蔚-一念之间.mp3","images":"img/a2.jpg"},
{"id":"128","name":"张歆艺-真·真.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张歆艺-真·真.mp3","images":"img/a3.jpg"},
{"id":"129","name":"张江-欢乐颂.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张江-欢乐颂.mp3","images":"img/a4.jpg"},
{"id":"130","name":"张玮-追爱.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张玮-追爱.mp3","images":"img/a5.jpg"},
{"id":"131","name":"张碧晨-下一秒.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张碧晨-下一秒.mp3","images":"img/a1.jpg"},
{"id":"132","name":"张碧晨-年少轻狂.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张碧晨-年少轻狂.mp3","images":"img/a2.jpg"},
{"id":"133","name":"张碧晨-年轮.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张碧晨-年轮.mp3","images":"img/a3.jpg"},
{"id":"134","name":"张磊-一念天堂.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张磊-一念天堂.mp3","images":"img/a4.jpg"},
{"id":"135","name":"张磊-人生是一次热血的流浪.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张磊-人生是一次热血的流浪.mp3","images":"img/a5.jpg"},
{"id":"136","name":"张磊-伤心是留给回忆的糖.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张磊-伤心是留给回忆的糖.mp3","images":"img/a1.jpg"},
{"id":"137","name":"张磊-相爱恨晚.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张磊-相爱恨晚.mp3","images":"img/a2.jpg"},
{"id":"138","name":"张磊-路远.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张磊-路远.mp3","images":"img/a3.jpg"},
{"id":"139","name":"张继聪-月无声.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张继聪-月无声.mp3","images":"img/a4.jpg"},
{"id":"140","name":"张翰-滚蛋歌.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张翰-滚蛋歌.mp3","images":"img/a5.jpg"},
{"id":"141","name":"张艺兴、姜雯、李小璐-青春快乐.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张艺兴、姜雯、李小璐-青春快乐.mp3","images":"img/a1.jpg"},
{"id":"142","name":"张若昀-最长的旅途.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张若昀-最长的旅途.mp3","images":"img/a2.jpg"},
{"id":"143","name":"张赫、白宇、张彬彬、崔航、郑业成-一笑倾城.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张赫、白宇、张彬彬、崔航、郑业成-一笑倾城.mp3","images":"img/a3.jpg"},
{"id":"144","name":"张赫宣-我们不该这样的.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张赫宣-我们不该这样的.mp3","images":"img/a4.jpg"},
{"id":"145","name":"张靓颖-Can'tHelpFallingInLove.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张靓颖-Can'tHelpFallingInLove.mp3","images":"img/a5.jpg"},
{"id":"146","name":"张靓颖、BigSean-FightingShadows.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/张靓颖、BigSean-FightingShadows.mp3","images":"img/a1.jpg"},
{"id":"147","name":"弦子-翻身吧!姐妹.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/弦子-翻身吧!姐妹.mp3","images":"img/a2.jpg"},
{"id":"148","name":"弦子、孟庭苇-还舍不得离别.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/弦子、孟庭苇-还舍不得离别.mp3","images":"img/a3.jpg"},
{"id":"149","name":"彭佳慧、F.I.R.-心之火.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/彭佳慧、F.I.R.-心之火.mp3","images":"img/a4.jpg"},
{"id":"150","name":"徐佳莹-女人花.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/徐佳莹-女人花.mp3","images":"img/a5.jpg"},
{"id":"151","name":"徐佳莹-潇洒走一回.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/徐佳莹-潇洒走一回.mp3","images":"img/a1.jpg"},
{"id":"152","name":"徐佳莹-遗忘之前.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/徐佳莹-遗忘之前.mp3","images":"img/a2.jpg"},
{"id":"153","name":"徐梵溪-燃烧翅膀.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/徐梵溪-燃烧翅膀.mp3","images":"img/a3.jpg"},
{"id":"154","name":"徐申东、阿宝-天天有喜.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/徐申东、阿宝-天天有喜.mp3","images":"img/a4.jpg"},
{"id":"155","name":"徐菲-树叶的光.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/徐菲-树叶的光.mp3","images":"img/a5.jpg"},
{"id":"156","name":"徐贤-我会等你.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/徐贤-我会等你.mp3","images":"img/a1.jpg"},
{"id":"157","name":"戚薇-陪你天涯.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/戚薇-陪你天涯.mp3","images":"img/a2.jpg"},
{"id":"158","name":"戴佩妮-非诚勿扰.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/戴佩妮-非诚勿扰.mp3","images":"img/a3.jpg"},
{"id":"159","name":"手嶌葵-明日への手紙.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/手嶌葵-明日への手紙.mp3","images":"img/a4.jpg"},
{"id":"160","name":"星-Remember.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/星-Remember.mp3","images":"img/a5.jpg"},
{"id":"161","name":"曹洋-解开.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/曹洋-解开.mp3","images":"img/a1.jpg"},
{"id":"162","name":"曹璐-等你开口.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/曹璐-等你开口.mp3","images":"img/a2.jpg"},
{"id":"163","name":"曹轩宾-轻轻.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/曹轩宾-轻轻.mp3","images":"img/a3.jpg"},
{"id":"164","name":"曾一鸣-冷红颜.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/曾一鸣-冷红颜.mp3","images":"img/a4.jpg"},
{"id":"165","name":"曾一鸣-时光尽头的恋人.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/曾一鸣-时光尽头的恋人.mp3","images":"img/a5.jpg"},
{"id":"166","name":"曾咏欣-心的构造.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/曾咏欣-心的构造.mp3","images":"img/a1.jpg"},
{"id":"167","name":"曾沛慈-我不是你该爱的那个人.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/曾沛慈-我不是你该爱的那个人.mp3","images":"img/a2.jpg"},
{"id":"168","name":"曾雨轩-幸福的味道.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/曾雨轩-幸福的味道.mp3","images":"img/a3.jpg"},
{"id":"169","name":"朱明-好好爱你一辈子.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/朱明-好好爱你一辈子.mp3","images":"img/a4.jpg"},
{"id":"170","name":"朴容仁、权顺日-NoWay.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/朴容仁、权顺日-NoWay.mp3","images":"img/a5.jpg"},
{"id":"171","name":"朴树-在木星.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/朴树-在木星.mp3","images":"img/a1.jpg"},
{"id":"172","name":"权振东-你什么都想要.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/权振东-你什么都想要.mp3","images":"img/a2.jpg"},
{"id":"173","name":"李健-假如爱有天意.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/李健-假如爱有天意.mp3","images":"img/a3.jpg"},
{"id":"174","name":"李宇春-山河故人.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/李宇春-山河故人.mp3","images":"img/a4.jpg"},
{"id":"175","name":"李小璐、贾乃亮-多面娇娃.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/李小璐、贾乃亮-多面娇娃.mp3","images":"img/a5.jpg"},
{"id":"176","name":"李易峰-年少有你.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/李易峰-年少有你.mp3","images":"img/a1.jpg"},
{"id":"177","name":"李易峰-请跟我联络.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/李易峰-请跟我联络.mp3","images":"img/a2.jpg"},
{"id":"178","name":"李晓杰、陈星、程巍、牛朝阳-美人酒.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/李晓杰、陈星、程巍、牛朝阳-美人酒.mp3","images":"img/a3.jpg"},
{"id":"179","name":"李泰-冷战.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/李泰-冷战.mp3","images":"img/a4.jpg"},
{"id":"180","name":"李维真-你一直在我心里.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/李维真-你一直在我心里.mp3","images":"img/a5.jpg"},
{"id":"181","name":"李荣浩-不将就.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/李荣浩-不将就.mp3","images":"img/a1.jpg"},
{"id":"182","name":"李荣浩-不说.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/李荣浩-不说.mp3","images":"img/a2.jpg"},
{"id":"183","name":"李锡勋-I'llBeThere.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/李锡勋-I'llBeThere.mp3","images":"img/a3.jpg"},
{"id":"184","name":"李阳-给我点时间.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/李阳-给我点时间.mp3","images":"img/a4.jpg"},
{"id":"185","name":"李雅萱-不一样的女人.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/李雅萱-不一样的女人.mp3","images":"img/a5.jpg"},
{"id":"186","name":"杨坤-爱简单.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/杨坤-爱简单.mp3","images":"img/a1.jpg"},
{"id":"187","name":"杨坤、陈学冬、张杰、郑元畅、佟大为、朱亚文-真心英雄.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/杨坤、陈学冬、张杰、郑元畅、佟大为、朱亚文-真心英雄.mp3","images":"img/a2.jpg"},
{"id":"188","name":"杨宗纬-一次就好.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/杨宗纬-一次就好.mp3","images":"img/a3.jpg"},
{"id":"189","name":"杨宗纬-真相禁区.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/杨宗纬-真相禁区.mp3","images":"img/a4.jpg"},
{"id":"190","name":"杨洋-微微一笑很倾城.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/杨洋-微微一笑很倾城.mp3","images":"img/a5.jpg"},
{"id":"191","name":"杨珏婷-NeverSayGoodbye.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/杨珏婷-NeverSayGoodbye.mp3","images":"img/a1.jpg"},
{"id":"192","name":"杨紫-开得比花香.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/杨紫-开得比花香.mp3","images":"img/a2.jpg"},
{"id":"193","name":"林峯-心有灵犀.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/林峯-心有灵犀.mp3","images":"img/a3.jpg"},
{"id":"194","name":"林明祯-小秘密.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/林明祯-小秘密.mp3","images":"img/a4.jpg"},
{"id":"195","name":"林采欣-一秒时光.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/林采欣-一秒时光.mp3","images":"img/a5.jpg"},
{"id":"196","name":"柯有伦、崔允素-为爱.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/柯有伦、崔允素-为爱.mp3","images":"img/a1.jpg"},
{"id":"197","name":"梁文音-寂寞之光.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/梁文音-寂寞之光.mp3","images":"img/a2.jpg"},
{"id":"198","name":"梁静茹-在爱里等你.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/梁静茹-在爱里等你.mp3","images":"img/a3.jpg"},
{"id":"199","name":"樊凡-转身.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/樊凡-转身.mp3","images":"img/a4.jpg"},
{"id":"200","name":"樊凡-逆向爱情.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/樊凡-逆向爱情.mp3","images":"img/a5.jpg"},
{"id":"201","name":"樊凡-非我不可.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/樊凡-非我不可.mp3","images":"img/a1.jpg"},
{"id":"202","name":"橋本環奈-セーラー服と機関銃.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/橋本環奈-セーラー服と機関銃.mp3","images":"img/a2.jpg"},
{"id":"203","name":"欧豪、杨洋、胡夏-放心去飞.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/欧豪、杨洋、胡夏-放心去飞.mp3","images":"img/a3.jpg"},
{"id":"204","name":"欧阳娜娜-温暖你的冬.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/欧阳娜娜-温暖你的冬.mp3","images":"img/a4.jpg"},
{"id":"205","name":"毛泽少-思雨蝶.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/毛泽少-思雨蝶.mp3","images":"img/a5.jpg"},
{"id":"206","name":"水木年华-唯你一生.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/水木年华-唯你一生.mp3","images":"img/a1.jpg"},
{"id":"207","name":"江一燕-我不.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/江一燕-我不.mp3","images":"img/a2.jpg"},
{"id":"208","name":"江映蓉-爱如传奇.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/江映蓉-爱如传奇.mp3","images":"img/a3.jpg"},
{"id":"209","name":"池城-紫罗兰.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/池城-紫罗兰.mp3","images":"img/a4.jpg"},
{"id":"210","name":"汤唯-我曾经也想过一了百了.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/汤唯-我曾经也想过一了百了.mp3","images":"img/a5.jpg"},
{"id":"211","name":"汪小敏-空.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/汪小敏-空.mp3","images":"img/a1.jpg"},
{"id":"212","name":"汪苏泷-π之歌.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/汪苏泷-π之歌.mp3","images":"img/a2.jpg"},
{"id":"213","name":"汪苏泷-一笑倾城.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/汪苏泷-一笑倾城.mp3","images":"img/a3.jpg"},
{"id":"214","name":"汪苏泷-严小姐.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/汪苏泷-严小姐.mp3","images":"img/a4.jpg"},
{"id":"215","name":"汪苏泷-如果时光倒流.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/汪苏泷-如果时光倒流.mp3","images":"img/a5.jpg"},
{"id":"216","name":"汪苏泷-心跳.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/汪苏泷-心跳.mp3","images":"img/a1.jpg"},
{"id":"217","name":"汪苏泷-爱让我勇敢.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/汪苏泷-爱让我勇敢.mp3","images":"img/a2.jpg"},
{"id":"218","name":"沈依莎-时过境迁.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/沈依莎-时过境迁.mp3","images":"img/a3.jpg"},
{"id":"219","name":"沈腾-一次就好.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/沈腾-一次就好.mp3","images":"img/a4.jpg"},
{"id":"220","name":"沈震轩-蓝天白云.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/沈震轩-蓝天白云.mp3","images":"img/a5.jpg"},
{"id":"221","name":"沙宝亮-有种你爱我.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/沙宝亮-有种你爱我.mp3","images":"img/a1.jpg"},
{"id":"222","name":"温岚-FlyWithMe.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/温岚-FlyWithMe.mp3","images":"img/a2.jpg"},
{"id":"223","name":"满江-Mr.Man.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/满江-Mr.Man.mp3","images":"img/a3.jpg"},
{"id":"224","name":"潘长江-灯火.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/潘长江-灯火.mp3","images":"img/a4.jpg"},
{"id":"225","name":"焕熙-??????.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/焕熙-??????.mp3","images":"img/a5.jpg"},
{"id":"226","name":"爱纱、呆宝静-真相.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/爱纱、呆宝静-真相.mp3","images":"img/a1.jpg"},
{"id":"227","name":"牛奶咖啡-星星.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/牛奶咖啡-星星.mp3","images":"img/a2.jpg"},
{"id":"228","name":"王凯-赤血长殷.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/王凯-赤血长殷.mp3","images":"img/a3.jpg"},
{"id":"229","name":"王力宏-就是现在我看你有戏.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/王力宏-就是现在我看你有戏.mp3","images":"img/a4.jpg"},
{"id":"230","name":"王大文-云霄飞车.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/王大文-云霄飞车.mp3","images":"img/a5.jpg"},
{"id":"231","name":"王大文-其实你已经知道.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/王大文-其实你已经知道.mp3","images":"img/a1.jpg"},
{"id":"232","name":"王思远-逐鹿.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/王思远-逐鹿.mp3","images":"img/a2.jpg"},
{"id":"233","name":"王栎鑫-最好的我们.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/王栎鑫-最好的我们.mp3","images":"img/a3.jpg"},
{"id":"234","name":"王珞丹-如果遇见.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/王珞丹-如果遇见.mp3","images":"img/a4.jpg"},
{"id":"235","name":"王祖蓝、刘维-Brother.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/王祖蓝、刘维-Brother.mp3","images":"img/a5.jpg"},
{"id":"236","name":"王蓉-高跟鞋先生.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/王蓉-高跟鞋先生.mp3","images":"img/a1.jpg"},
{"id":"237","name":"王蓉、东山少爷-叶问.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/王蓉、东山少爷-叶问.mp3","images":"img/a2.jpg"},
{"id":"238","name":"王蓉、老猫、杨望-叶问.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/王蓉、老猫、杨望-叶问.mp3","images":"img/a3.jpg"},
{"id":"239","name":"王诗龄、Kimi、张悦轩、郭子睿-爸爸的假期.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/王诗龄、Kimi、张悦轩、郭子睿-爸爸的假期.mp3","images":"img/a4.jpg"},
{"id":"240","name":"王铮亮-相爱一场.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/王铮亮-相爱一场.mp3","images":"img/a5.jpg"},
{"id":"241","name":"王铮亮-越走越远的旅客.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/王铮亮-越走越远的旅客.mp3","images":"img/a1.jpg"},
{"id":"242","name":"田雷-找找爱.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/田雷-找找爱.mp3","images":"img/a2.jpg"},
{"id":"243","name":"白举纲、于湉-一首热血的歌.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/白举纲、于湉-一首热血的歌.mp3","images":"img/a3.jpg"},
{"id":"244","name":"白智英-BecauseOfYou.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/白智英-BecauseOfYou.mp3","images":"img/a4.jpg"},
{"id":"245","name":"盛一伦-漩涡.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/盛一伦-漩涡.mp3","images":"img/a5.jpg"},
{"id":"246","name":"祖峰-空气.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/祖峰-空气.mp3","images":"img/a1.jpg"},
{"id":"247","name":"祖峰-陪你左右.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/祖峰-陪你左右.mp3","images":"img/a2.jpg"},
{"id":"248","name":"秦勇-回家的路.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/秦勇-回家的路.mp3","images":"img/a3.jpg"},
{"id":"249","name":"秦基博-スミレ.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/秦基博-スミレ.mp3","images":"img/a4.jpg"},
{"id":"250","name":"程堃-如果,再见.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/程堃-如果,再见.mp3","images":"img/a5.jpg"},
{"id":"251","name":"筷子兄弟-奔跑吧兄弟.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/筷子兄弟-奔跑吧兄弟.mp3","images":"img/a1.jpg"},
{"id":"252","name":"筷子兄弟-铁拳.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/筷子兄弟-铁拳.mp3","images":"img/a2.jpg"},
{"id":"253","name":"简弘亦-情义盖过天.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/简弘亦-情义盖过天.mp3","images":"img/a3.jpg"},
{"id":"254","name":"简弘亦-战鹰.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/简弘亦-战鹰.mp3","images":"img/a4.jpg"},
{"id":"255","name":"简弘亦-第九十九滴眼泪.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/简弘亦-第九十九滴眼泪.mp3","images":"img/a5.jpg"},
{"id":"256","name":"罗中旭-恋人.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/罗中旭-恋人.mp3","images":"img/a1.jpg"},
{"id":"257","name":"罗大佑、台北爱乐合唱团-穿越漩涡.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/罗大佑、台北爱乐合唱团-穿越漩涡.mp3","images":"img/a2.jpg"},
{"id":"258","name":"罗晋-如果我答应你.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/罗晋-如果我答应你.mp3","images":"img/a3.jpg"},
{"id":"259","name":"翟天临、江铠同-潜爱.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/翟天临、江铠同-潜爱.mp3","images":"img/a4.jpg"},
{"id":"260","name":"胡夏-他比我更适合.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/胡夏-他比我更适合.mp3","images":"img/a5.jpg"},
{"id":"261","name":"胡夏-爱你步步惊心.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/胡夏-爱你步步惊心.mp3","images":"img/a1.jpg"},
{"id":"262","name":"胡夏-给我的快乐.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/胡夏-给我的快乐.mp3","images":"img/a2.jpg"},
{"id":"263","name":"胡彦斌-还魂门.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/胡彦斌-还魂门.mp3","images":"img/a3.jpg"},
{"id":"264","name":"胡杏儿-天使.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/胡杏儿-天使.mp3","images":"img/a4.jpg"},
{"id":"265","name":"胡歌-风起时.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/胡歌-风起时.mp3","images":"img/a5.jpg"},
{"id":"266","name":"胡莎莎-我是你的女侠.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/胡莎莎-我是你的女侠.mp3","images":"img/a1.jpg"},
{"id":"267","name":"胡莎莎-离人劫.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/胡莎莎-离人劫.mp3","images":"img/a2.jpg"},
{"id":"268","name":"胡鸿钧-天地不容.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/胡鸿钧-天地不容.mp3","images":"img/a3.jpg"},
{"id":"269","name":"胡鸿钧-灵魂的痛.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/胡鸿钧-灵魂的痛.mp3","images":"img/a4.jpg"},
{"id":"270","name":"苏盈之、陈晓东-幸福满满.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/苏盈之、陈晓东-幸福满满.mp3","images":"img/a5.jpg"},
{"id":"271","name":"范逸臣-秀丽江山.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/范逸臣-秀丽江山.mp3","images":"img/a1.jpg"},
{"id":"272","name":"蒋卓嘉-伤寒.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/蒋卓嘉-伤寒.mp3","images":"img/a2.jpg"},
{"id":"273","name":"蒋卓嘉-预告.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/蒋卓嘉-预告.mp3","images":"img/a3.jpg"},
{"id":"274","name":"蔡健雅-停格.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/蔡健雅-停格.mp3","images":"img/a4.jpg"},
{"id":"275","name":"薛之谦、黄龄-来日方长.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/薛之谦、黄龄-来日方长.mp3","images":"img/a5.jpg"},
{"id":"276","name":"藏古西烈、王叠-月恋.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/藏古西烈、王叠-月恋.mp3","images":"img/a1.jpg"},
{"id":"277","name":"西内まりや-SaveMe.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/西内まりや-SaveMe.mp3","images":"img/a2.jpg"},
{"id":"278","name":"西瓜JUN-海洋之歌.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/西瓜JUN-海洋之歌.mp3","images":"img/a3.jpg"},
{"id":"279","name":"许嵩-不语.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/许嵩-不语.mp3","images":"img/a4.jpg"},
{"id":"280","name":"许廷铿-迷宫.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/许廷铿-迷宫.mp3","images":"img/a5.jpg"},
{"id":"281","name":"许飞-不说再见.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/许飞-不说再见.mp3","images":"img/a1.jpg"},
{"id":"282","name":"许魏洲-向着光亮那方.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/许魏洲-向着光亮那方.mp3","images":"img/a2.jpg"},
{"id":"283","name":"许魏洲-慢慢走.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/许魏洲-慢慢走.mp3","images":"img/a3.jpg"},
{"id":"284","name":"谢安琪-诸神混乱.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/谢安琪-诸神混乱.mp3","images":"img/a4.jpg"},
{"id":"285","name":"谢容儿-血娃娃.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/谢容儿-血娃娃.mp3","images":"img/a5.jpg"},
{"id":"286","name":"谭维维-三十岁的女人.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/谭维维-三十岁的女人.mp3","images":"img/a1.jpg"},
{"id":"287","name":"谭维维-地狱就是天堂.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/谭维维-地狱就是天堂.mp3","images":"img/a2.jpg"},
{"id":"288","name":"谭维维-无问.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/谭维维-无问.mp3","images":"img/a3.jpg"},
{"id":"289","name":"谭维维-煎饼侠.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/谭维维-煎饼侠.mp3","images":"img/a4.jpg"},
{"id":"290","name":"谭维维-爱到底.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/谭维维-爱到底.mp3","images":"img/a5.jpg"},
{"id":"291","name":"贾乃亮-炽热的青春.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/贾乃亮-炽热的青春.mp3","images":"img/a1.jpg"},
{"id":"292","name":"贾乃亮-讨喜.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/贾乃亮-讨喜.mp3","images":"img/a2.jpg"},
{"id":"293","name":"贾青-傻得可以.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/贾青-傻得可以.mp3","images":"img/a3.jpg"},
{"id":"294","name":"赵丽颖-心念.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/赵丽颖-心念.mp3","images":"img/a4.jpg"},
{"id":"295","name":"赵丽颖、许志安-乱世俱灭.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/赵丽颖、许志安-乱世俱灭.mp3","images":"img/a5.jpg"},
{"id":"296","name":"赵婧贻-直到时间尽头.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/赵婧贻-直到时间尽头.mp3","images":"img/a1.jpg"},
{"id":"297","name":"赵照-你就是我最想要的丫头.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/赵照-你就是我最想要的丫头.mp3","images":"img/a2.jpg"},
{"id":"298","name":"赵照-当你老了.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/赵照-当你老了.mp3","images":"img/a3.jpg"},
{"id":"299","name":"赵英俊-大王叫我来巡山.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/赵英俊-大王叫我来巡山.mp3","images":"img/a4.jpg"},
{"id":"300","name":"赵英俊、万万天团-万万.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/赵英俊、万万天团-万万.mp3","images":"img/a5.jpg"},
{"id":"301","name":"赵薇-左耳.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/赵薇-左耳.mp3","images":"img/a1.jpg"},
{"id":"302","name":"迪克牛仔-蒸发太平洋.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/迪克牛仔-蒸发太平洋.mp3","images":"img/a2.jpg"},
{"id":"303","name":"邓超-娘娘我错了.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/邓超-娘娘我错了.mp3","images":"img/a3.jpg"},
{"id":"304","name":"邓超、小臭臭-小尾巴之歌.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/邓超、小臭臭-小尾巴之歌.mp3","images":"img/a4.jpg"},
{"id":"305","name":"那英-对的人.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/那英-对的人.mp3","images":"img/a5.jpg"},
{"id":"306","name":"那英-有个爱你的人不容易.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/那英-有个爱你的人不容易.mp3","images":"img/a1.jpg"},
{"id":"307","name":"那英-相爱恨早.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/那英-相爱恨早.mp3","images":"img/a2.jpg"},
{"id":"308","name":"那英-默.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/那英-默.mp3","images":"img/a3.jpg"},
{"id":"309","name":"郁可唯-我们都爱过.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/郁可唯-我们都爱过.mp3","images":"img/a4.jpg"},
{"id":"310","name":"郁可唯-爱情是青春的旅行.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/郁可唯-爱情是青春的旅行.mp3","images":"img/a5.jpg"},
{"id":"311","name":"郁可唯-风中芭蕾.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/郁可唯-风中芭蕾.mp3","images":"img/a1.jpg"},
{"id":"312","name":"郑俊弘-火线下.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/郑俊弘-火线下.mp3","images":"img/a2.jpg"},
{"id":"313","name":"郑恺-时光倒回.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/郑恺-时光倒回.mp3","images":"img/a3.jpg"},
{"id":"314","name":"郑烨-耀眼的一天.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/郑烨-耀眼的一天.mp3","images":"img/a4.jpg"},
{"id":"315","name":"郑烨-??(愛).mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/郑烨-??(愛).mp3","images":"img/a5.jpg"},
{"id":"316","name":"郑胜焕-????.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/郑胜焕-????.mp3","images":"img/a1.jpg"},
{"id":"317","name":"郑雅文-寂寞旅途.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/郑雅文-寂寞旅途.mp3","images":"img/a2.jpg"},
{"id":"318","name":"郭子睿-小猪歌.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/郭子睿-小猪歌.mp3","images":"img/a3.jpg"},
{"id":"319","name":"郭富城-就是孙悟空.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/郭富城-就是孙悟空.mp3","images":"img/a4.jpg"},
{"id":"320","name":"都智文-将就.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/都智文-将就.mp3","images":"img/a5.jpg"},
{"id":"321","name":"金志文-尘.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/金志文-尘.mp3","images":"img/a1.jpg"},
{"id":"322","name":"金志文-我们结婚吧.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/金志文-我们结婚吧.mp3","images":"img/a2.jpg"},
{"id":"323","name":"金志文、谭维维、陈楚生、吉克隽逸-巴黎假期.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/金志文、谭维维、陈楚生、吉克隽逸-巴黎假期.mp3","images":"img/a3.jpg"},
{"id":"324","name":"金桢勋-英雄.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/金桢勋-英雄.mp3","images":"img/a4.jpg"},
{"id":"325","name":"金池-勇气.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/金池-勇气.mp3","images":"img/a5.jpg"},
{"id":"326","name":"金池-好过纠缠.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/金池-好过纠缠.mp3","images":"img/a1.jpg"},
{"id":"327","name":"金池-爱过了站.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/金池-爱过了站.mp3","images":"img/a2.jpg"},
{"id":"328","name":"金莎-诺.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/金莎-诺.mp3","images":"img/a3.jpg"},
{"id":"329","name":"金韩一-不能做朋友.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/金韩一-不能做朋友.mp3","images":"img/a4.jpg"},
{"id":"330","name":"钟嘉欣-你懂我.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/钟嘉欣-你懂我.mp3","images":"img/a5.jpg"},
{"id":"331","name":"钟嘉欣-我不够好.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/钟嘉欣-我不够好.mp3","images":"img/a1.jpg"},
{"id":"332","name":"钟汉良-何以爱情.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/钟汉良-何以爱情.mp3","images":"img/a2.jpg"},
{"id":"333","name":"钟汉良-奇书.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/钟汉良-奇书.mp3","images":"img/a3.jpg"},
{"id":"334","name":"钟汉良-普通人.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/钟汉良-普通人.mp3","images":"img/a4.jpg"},
{"id":"335","name":"长宇-我想.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/长宇-我想.mp3","images":"img/a5.jpg"},
{"id":"336","name":"阚立文-谢谢你对不起.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/阚立文-谢谢你对不起.mp3","images":"img/a1.jpg"},
{"id":"337","name":"阿兰-千古.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/阿兰-千古.mp3","images":"img/a2.jpg"},
{"id":"338","name":"阿悄、童可可、微胖女神-气质少女.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/阿悄、童可可、微胖女神-气质少女.mp3","images":"img/a3.jpg"},
{"id":"339","name":"阿鲁阿卓-西风.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/阿鲁阿卓-西风.mp3","images":"img/a4.jpg"},
{"id":"340","name":"陆星材、朴慧秀-LoveSong.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陆星材、朴慧秀-LoveSong.mp3","images":"img/a5.jpg"},
{"id":"341","name":"陈伟霆-我门.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈伟霆-我门.mp3","images":"img/a1.jpg"},
{"id":"342","name":"陈坤-寻龙诀.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈坤-寻龙诀.mp3","images":"img/a2.jpg"},
{"id":"343","name":"陈奕、沈建宏-爱她.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈奕、沈建宏-爱她.mp3","images":"img/a3.jpg"},
{"id":"344","name":"陈奕迅-恐龙进化论.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈奕迅-恐龙进化论.mp3","images":"img/a4.jpg"},
{"id":"345","name":"陈奕迅-陪你度过漫长岁月.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈奕迅-陪你度过漫长岁月.mp3","images":"img/a5.jpg"},
{"id":"346","name":"陈学冬-岁月缝花.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈学冬-岁月缝花.mp3","images":"img/a1.jpg"},
{"id":"347","name":"陈学冬-碎碎恋.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈学冬-碎碎恋.mp3","images":"img/a2.jpg"},
{"id":"348","name":"陈建斌、羽·泉-向雪祈祷.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈建斌、羽·泉-向雪祈祷.mp3","images":"img/a3.jpg"},
{"id":"349","name":"陈思思-满月.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈思思-满月.mp3","images":"img/a4.jpg"},
{"id":"350","name":"陈思诚、王宝强-往事只能回味.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈思诚、王宝强-往事只能回味.mp3","images":"img/a5.jpg"},
{"id":"351","name":"陈意涵-最美的情书.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈意涵-最美的情书.mp3","images":"img/a1.jpg"},
{"id":"352","name":"陈明-爱需要练习.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈明-爱需要练习.mp3","images":"img/a2.jpg"},
{"id":"353","name":"陈明-谁懂女人心.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈明-谁懂女人心.mp3","images":"img/a3.jpg"},
{"id":"354","name":"陈楚生-后来的事.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈楚生-后来的事.mp3","images":"img/a4.jpg"},
{"id":"355","name":"陈洁仪-从前的我.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈洁仪-从前的我.mp3","images":"img/a5.jpg"},
{"id":"356","name":"陈洁仪-心动.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈洁仪-心动.mp3","images":"img/a1.jpg"},
{"id":"357","name":"陈洁仪-祝君好.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈洁仪-祝君好.mp3","images":"img/a2.jpg"},
{"id":"358","name":"陈翔-到不了.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈翔-到不了.mp3","images":"img/a3.jpg"},
{"id":"359","name":"陈翔-只是朋友.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈翔-只是朋友.mp3","images":"img/a4.jpg"},
{"id":"360","name":"陈翔-热血.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈翔-热血.mp3","images":"img/a5.jpg"},
{"id":"361","name":"陈赫、姚晨、窦骁、叶一云-一封家书.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈赫、姚晨、窦骁、叶一云-一封家书.mp3","images":"img/a1.jpg"},
{"id":"362","name":"陈雅菁-开始想你的好.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/陈雅菁-开始想你的好.mp3","images":"img/a2.jpg"},
{"id":"363","name":"霍尊-之子于归.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/霍尊-之子于归.mp3","images":"img/a3.jpg"},
{"id":"364","name":"霍尊-伊人如梦.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/霍尊-伊人如梦.mp3","images":"img/a4.jpg"},
{"id":"365","name":"霍尊-梨花落.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/霍尊-梨花落.mp3","images":"img/a5.jpg"},
{"id":"366","name":"霍建华、赵丽颖-不可说.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/霍建华、赵丽颖-不可说.mp3","images":"img/a1.jpg"},
{"id":"367","name":"韩东君-无法说爱.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/韩东君-无法说爱.mp3","images":"img/a2.jpg"},
{"id":"368","name":"韩磊-千年一般若.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/韩磊-千年一般若.mp3","images":"img/a3.jpg"},
{"id":"369","name":"韩磊-道在何方.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/韩磊-道在何方.mp3","images":"img/a4.jpg"},
{"id":"370","name":"韩红-灵犀一动.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/韩红-灵犀一动.mp3","images":"img/a5.jpg"},
{"id":"371","name":"韩红-青春.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/韩红-青春.mp3","images":"img/a1.jpg"},
{"id":"372","name":"音频怪物-典狱司.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/音频怪物-典狱司.mp3","images":"img/a2.jpg"},
{"id":"373","name":"音频怪物-英雄难做.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/音频怪物-英雄难做.mp3","images":"img/a3.jpg"},
{"id":"374","name":"颖儿-他们.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/颖儿-他们.mp3","images":"img/a4.jpg"},
{"id":"375","name":"香香-初见爱已晚.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/香香-初见爱已晚.mp3","images":"img/a5.jpg"},
{"id":"376","name":"香香-恋歌.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/香香-恋歌.mp3","images":"img/a1.jpg"},
{"id":"377","name":"香香-爱情砂砾.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/香香-爱情砂砾.mp3","images":"img/a2.jpg"},
{"id":"378","name":"马振桓、熊梓淇-剑心飞扬.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/马振桓、熊梓淇-剑心飞扬.mp3","images":"img/a3.jpg"},
{"id":"379","name":"魏大勋-像你这样的女孩.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/魏大勋-像你这样的女孩.mp3","images":"img/a4.jpg"},
{"id":"380","name":"魏晨-烈火神盾.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/魏晨-烈火神盾.mp3","images":"img/a5.jpg"},
{"id":"381","name":"魏晨-爱我就陪我看电影.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/魏晨-爱我就陪我看电影.mp3","images":"img/a1.jpg"},
{"id":"382","name":"魏晨-相爱不能见.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/魏晨-相爱不能见.mp3","images":"img/a2.jpg"},
{"id":"383","name":"魏晨-破绽.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/魏晨-破绽.mp3","images":"img/a3.jpg"},
{"id":"384","name":"魏语诺-星语心愿.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/魏语诺-星语心愿.mp3","images":"img/a4.jpg"},
{"id":"385","name":"鲁士郎-相信你,相信我.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/鲁士郎-相信你,相信我.mp3","images":"img/a5.jpg"},
{"id":"386","name":"鲁士郎、钟纯妍-再见少年.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/鲁士郎、钟纯妍-再见少年.mp3","images":"img/a1.jpg"},
{"id":"387","name":"鹿晗-勋章.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/鹿晗-勋章.mp3","images":"img/a2.jpg"},
{"id":"388","name":"鹿晗-甜蜜蜜.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/鹿晗-甜蜜蜜.mp3","images":"img/a3.jpg"},
{"id":"389","name":"黄晓明-缘.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/黄晓明-缘.mp3","images":"img/a4.jpg"},
{"id":"390","name":"黄渤、小柯-我也曾经像你一样.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/黄渤、小柯-我也曾经像你一样.mp3","images":"img/a5.jpg"},
{"id":"391","name":"黄磊、多多、曹格、曹三丰、Grace、杨威、杨阳洋、陆毅、贝儿-么么哒.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/黄磊、多多、曹格、曹三丰、Grace、杨威、杨阳洋、陆毅、贝儿-么么哒.mp3","images":"img/a1.jpg"},
{"id":"392","name":"黄阅-守望.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/黄阅-守望.mp3","images":"img/a2.jpg"},
{"id":"393","name":"黄雅莉-古耐.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/黄雅莉-古耐.mp3","images":"img/a3.jpg"},
{"id":"394","name":"黄龄-禁区.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/黄龄-禁区.mp3","images":"img/a4.jpg"},
{"id":"395","name":"黎明-情愿错过白天.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/黎明-情愿错过白天.mp3","images":"img/a5.jpg"},
{"id":"396","name":"龙梅子、葛荟婕-怒放.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/龙梅子、葛荟婕-怒放.mp3","images":"img/a1.jpg"},
{"id":"397","name":"龚淑均-思归.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/龚淑均-思归.mp3","images":"img/a2.jpg"},
{"id":"398","name":"龚琳娜-一个人没有同类.mp3","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/影视金曲榜/龚琳娜-一个人没有同类.mp3","images":"img/a3.jpg"},

    ]

//formateTime(61)--->01:01


//获取各种标签

    var player = document.querySelector("#player");
    var bz_music = document.querySelector("#bz_music");

    //歌曲信息部分
    var left_photo = document.querySelector("#left_photo");
    var list_title = document.querySelector("#list_title");
    var list_singer = document.querySelector("#list_singer");
    var process_slide = document.querySelector("#process_slide");
    var process = document.querySelector("#process");
    var showHide = document.querySelector("#showHide");
    
    //控制按钮部分
    var time = document.querySelector("#time");
    var　btnPlay　= document.querySelector("#btnPlay");
    var　volume_slide　= document.querySelector("#volume_slide");
    var　volume　= document.querySelector("#volume");
    
    //播放列表部分
    var play_list = document.querySelector("#play_list");
    
    var play_list_area = document.querySelector("#play_list_area");

//动态加载播放列表
    function loadPlayList(){
        //遍历播放列表
        for(var i=0;i<music_list.length;i++){
            //将每个对象，分别存到music中
            var music = music_list[i];
            //创建li标签
            var liTag = document.createElement("li");
            //创建歌曲名span标签
            var spanTitleTag = document.createElement("span");
            //创建时长span标签
            var spanDurationTag = document.createElement("span");
            
            //为ul添加li标签，子节点
            play_list.appendChild(liTag);
            //为li标签，添加子节点
            liTag.appendChild(spanTitleTag);
            liTag.appendChild(spanDurationTag);
            
            //添加内容
            spanTitleTag.innerHTML=music.name;
            spanDurationTag.innerHTML=music.duration;
            
            //添加类名
            spanTitleTag.classList.add("list_title");
            spanDurationTag.classList.add("list_time");
            
            //自定义属性
            //需要用的时候，直接从标签中取值，不需要和后台交互
            liTag.setAttribute("data-index",i);
            
            //当点击每一个li标签的时候
            //重新载入歌曲信息(专辑图片、歌曲路径、歌曲名、歌手名)
            //播放当前点击的音乐
            liTag.addEventListener("click",function(){
                //获取每个li标签的歌曲id
                var index = this.getAttribute("data-index");
//              console.log(index);
                //将歌曲id赋给，全局变量play_index
                play_index = index;
                //调用载入歌曲函数
                loadMusic();
                //播放音乐
                playMusic();
            })
        }
    }
    
//载入歌曲信息
    function loadMusic(){
        var music = music_list[play_index];
        //改变专辑图片
        left_photo.src = music.images;
        //改变歌曲名
        list_title.innerHTML = music.name;
        //改变歌手名
        list_singer.innerHTML = music.singer;
        //改变歌曲路径
        player.src = music.src;
    }
    
//播放,暂停音乐
    btnPlay.addEventListener("click",function(){
        //paused,表示当前音乐是否为暂停状态
        if(player.paused){
            //play(),播放当前音乐
            playMusic();
        }
        else {
            //pause(),暂停当前音乐
            player.pause();
            btnPlay.setAttribute("class","btn_play fa fa-play");
        }
    })

//上一曲
    function backword(){
        if(play_index==0){
            play_index=music_list.length-1;
        }
        else{
            //改变播放序号
            play_index--;
        }
        //重新载入
        loadMusic();
        //播放
        playMusic();   
    }
    
//下一曲
    function forward(){
        if(play_index==music_list.length-1){
            play_index=0;
        }
        else{
            //改变播放序号
            play_index++;
        }
        //重新载入
        loadMusic();
        //播放
        playMusic();   
    }
    
//播放
    function playMusic(){
        player.play();
        btnPlay.setAttribute("class","btn_play fa fa-pause"); 
    }



//时间转换

    function formateTime(time){
        if(time>3600){
            var hour = parseInt(time/3600);
            var minute = parseInt(time%3600/60);
            var second = parseInt(time%3600);
            hour=hour>=10?hour:"0"+hour;
            minute=minute>=10?minute:"0"+minute;
            second=second>=10?second:"0"+second;
            return hour+":"+minute+":"+second;
        }
        else{
            var minute = parseInt(time/60);
            var second = parseInt(time%60);
            minute=minute>=10?minute:"0"+minute;
            second=second>=10?second:"0"+second;
            return minute+":"+second;  
        }

    }
    
//设置定时器
    window.setInterval(function(){
        //currentTime,当前播放的秒数!
//      console.log(player.currentTime);
        time.innerHTML = formateTime(player.currentTime);
        //duration,当前音乐的总时长,秒数!!!
        var percent = player.currentTime/player.duration;
//      console.log(percent);
        process_slide.style.width=percent*100+"%";
    },100)
    
//静音
    function volumeOff(){
        //volume,[0,1]
        player.volume=0;
        volume_slide.style.width=0;
        console.log(player.volume);
    }
    
//最大音 
    function volumeUp(){
        player.volume=1;
        volume_slide.style.width="100%";
        console.log(player.volume);
    }

//通过滑块控制音量大小
    volume.addEventListener("click",function(event){
        //得到当前点击的位置
        var currentVolume = event.offsetX/this.offsetWidth;
        console.log(currentVolume);
        //设置音量
        player.volume=currentVolume;
        volume_slide.style.width = currentVolume*100+"%";
    })

//通过滑块控制音乐进度
    process.addEventListener("click",function(event){
        //计算点击位置的百分比
        var currentValue = event.offsetX/this.offsetWidth;
        
        //因为我们已经设置了定时器,在实时监控我们当前音乐的变化
        //因此,我们通过设置当前播放的音乐时长,影响我们的进度条
        player.currentTime = player.duration*currentValue;
    })

//显示隐藏播放列表
    function showMusicList(){
        //当前已经显示播放列表
        if(flag){
            play_list_area.style.display="none";
            bz_music.style.width="500px";
            showHide.style.color="#666";
            flag=0;
        }
        else {
            play_list_area.style.display="block";
            bz_music.style.width="700px";
            showHide.style.color="#DDD";
            flag=1;
        }
    }


//初始化
    //载入播放列表
    loadPlayList();
    //播放序号
    var play_index=0;
    //初始音量
    player.volume=0.5;
    //初始化显示播放列表
    //当flag为1的时候,表示列表显示(当前状态)
    //当flag为0的时候,表示列表隐藏(当前状态)
    var flag=1;

