﻿//播放列表
var music_list =[
{"id":"1","name":"冯提莫- 一个人失忆","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 一个人失忆.mp3","images":"img/a1.jpg"},
{"id":"2","name":"冯提莫- 一剪梅","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 一剪梅.mp3","images":"img/a2.jpg"},
{"id":"3","name":"冯提莫- 一千年以后","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 一千年以后.mp3","images":"img/a3.jpg"},
{"id":"4","name":"冯提莫- 一次就好","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 一次就好.mp3","images":"img/a4.jpg"},
{"id":"5","name":"冯提莫- 一生所爱","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 一生所爱.mp3","images":"img/a5.jpg"},
{"id":"6","name":"冯提莫- 一直很安静","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 一直很安静.mp3","images":"img/a1.jpg"},
{"id":"7","name":"冯提莫- 七里香","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 七里香.mp3","images":"img/a2.jpg"},
{"id":"8","name":"冯提莫- 万物生","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 万物生.mp3","images":"img/a3.jpg"},
{"id":"9","name":"冯提莫- 下个路口见","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 下个路口见.mp3","images":"img/a4.jpg"},
{"id":"10","name":"冯提莫- 下雨天","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 下雨天.mp3","images":"img/a5.jpg"},
{"id":"11","name":"冯提莫- 不再联系","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 不再联系.mp3","images":"img/a1.jpg"},
{"id":"12","name":"冯提莫- 不将就","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 不将就.mp3","images":"img/a2.jpg"},
{"id":"13","name":"冯提莫- 东京不太热","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 东京不太热.mp3","images":"img/a3.jpg"},
{"id":"14","name":"冯提莫- 为你我受冷风吹","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 为你我受冷风吹.mp3","images":"img/a4.jpg"},
{"id":"15","name":"冯提莫- 乌克丽丽","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 乌克丽丽.mp3","images":"img/a5.jpg"},
{"id":"16","name":"冯提莫- 五环之歌","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 五环之歌.mp3","images":"img/a1.jpg"},
{"id":"17","name":"冯提莫- 人质","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 人质.mp3","images":"img/a2.jpg"},
{"id":"18","name":"冯提莫- 人间 (2)","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 人间 (2).mp3","images":"img/a3.jpg"},
{"id":"19","name":"冯提莫- 人间","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 人间.mp3","images":"img/a4.jpg"},
{"id":"20","name":"冯提莫- 他一定很爱你","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 他一定很爱你.mp3","images":"img/a5.jpg"},
{"id":"21","name":"冯提莫- 他不爱我","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 他不爱我.mp3","images":"img/a1.jpg"},
{"id":"22","name":"冯提莫- 他说.wav","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 他说.wav","images":"img/a2.jpg"},
{"id":"23","name":"冯提莫- 传奇","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 传奇.mp3","images":"img/a3.jpg"},
{"id":"24","name":"冯提莫- 你一定要幸福","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 你一定要幸福.mp3","images":"img/a4.jpg"},
{"id":"25","name":"冯提莫- 你就不要想起我","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 你就不要想起我.mp3","images":"img/a5.jpg"},
{"id":"26","name":"冯提莫- 你是我最重要的决定","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 你是我最重要的决定.mp3","images":"img/a1.jpg"},
{"id":"27","name":"冯提莫- 你的甜蜜","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 你的甜蜜.mp3","images":"img/a2.jpg"},
{"id":"28","name":"冯提莫- 依恋","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 依恋.mp3","images":"img/a3.jpg"},
{"id":"29","name":"冯提莫- 修炼爱情","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 修炼爱情.mp3","images":"img/a4.jpg"},
{"id":"30","name":"冯提莫- 倩女幽魂","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 倩女幽魂.mp3","images":"img/a5.jpg"},
{"id":"31","name":"冯提莫- 倾城","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 倾城.mp3","images":"img/a1.jpg"},
{"id":"32","name":"冯提莫- 健康歌","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 健康歌.mp3","images":"img/a2.jpg"},
{"id":"33","name":"冯提莫- 光年之外","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 光年之外.mp3","images":"img/a3.jpg"},
{"id":"34","name":"冯提莫- 六月的雨","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 六月的雨.mp3","images":"img/a4.jpg"},
{"id":"35","name":"冯提莫- 写不出的温柔","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 写不出的温柔.mp3","images":"img/a5.jpg"},
{"id":"36","name":"冯提莫- 写不完的温柔","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 写不完的温柔.mp3","images":"img/a1.jpg"},
{"id":"37","name":"冯提莫- 凉凉","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 凉凉.mp3","images":"img/a2.jpg"},
{"id":"38","name":"冯提莫- 分手快乐","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 分手快乐.mp3","images":"img/a3.jpg"},
{"id":"39","name":"冯提莫- 别找我麻烦","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 别找我麻烦.mp3","images":"img/a4.jpg"},
{"id":"40","name":"冯提莫- 匆匆那年","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 匆匆那年.mp3","images":"img/a5.jpg"},
{"id":"41","name":"冯提莫- 十年","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 十年.mp3","images":"img/a1.jpg"},
{"id":"42","name":"冯提莫- 千年之恋","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 千年之恋.mp3","images":"img/a2.jpg"},
{"id":"43","name":"冯提莫- 单身情歌","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 单身情歌.mp3","images":"img/a3.jpg"},
{"id":"44","name":"冯提莫- 单飞","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 单飞.mp3","images":"img/a4.jpg"},
{"id":"45","name":"冯提莫- 南山南","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 南山南.mp3","images":"img/a5.jpg"},
{"id":"46","name":"冯提莫- 卜卦","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 卜卦.mp3","images":"img/a1.jpg"},
{"id":"47","name":"冯提莫- 卜挂","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 卜挂.mp3","images":"img/a2.jpg"},
{"id":"48","name":"冯提莫- 卜掛","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 卜掛.mp3","images":"img/a3.jpg"},
{"id":"49","name":"冯提莫- 卷珠帘","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 卷珠帘.mp3","images":"img/a4.jpg"},
{"id":"50","name":"冯提莫- 友情岁月","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 友情岁月.mp3","images":"img/a5.jpg"},
{"id":"51","name":"冯提莫- 反叛","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 反叛.mp3","images":"img/a1.jpg"},
{"id":"52","name":"冯提莫- 口香糖","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 口香糖.mp3","images":"img/a2.jpg"},
{"id":"53","name":"冯提莫- 古灵精怪","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 古灵精怪.mp3","images":"img/a3.jpg"},
{"id":"54","name":"冯提莫- 可惜不是你","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 可惜不是你.mp3","images":"img/a4.jpg"},
{"id":"55","name":"冯提莫- 可惜没如果","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 可惜没如果.mp3","images":"img/a5.jpg"},
{"id":"56","name":"冯提莫- 可爱颂","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 可爱颂.mp3","images":"img/a1.jpg"},
{"id":"57","name":"冯提莫- 可爱颂.mp4","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 可爱颂.mp4","images":"img/a2.jpg"},
{"id":"58","name":"冯提莫- 叶子","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 叶子.mp3","images":"img/a3.jpg"},
{"id":"59","name":"冯提莫- 告白气球","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 告白气球.mp3","images":"img/a4.jpg"},
{"id":"60","name":"冯提莫- 告诉我","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 告诉我.mp3","images":"img/a5.jpg"},
{"id":"61","name":"冯提莫- 哈巴狗","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 哈巴狗.mp3","images":"img/a1.jpg"},
{"id":"62","name":"冯提莫- 喜欢你","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 喜欢你.mp3","images":"img/a2.jpg"},
{"id":"63","name":"冯提莫- 囚鸟","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 囚鸟.mp3","images":"img/a3.jpg"},
{"id":"64","name":"冯提莫- 回到过去","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 回到过去.mp3","images":"img/a4.jpg"},
{"id":"65","name":"冯提莫- 在雨中","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 在雨中.mp3","images":"img/a5.jpg"},
{"id":"66","name":"冯提莫- 夏天的风","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 夏天的风.mp3","images":"img/a1.jpg"},
{"id":"67","name":"冯提莫- 多远都要在一起","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 多远都要在一起.mp3","images":"img/a2.jpg"},
{"id":"68","name":"冯提莫- 夜车","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 夜车.mp3","images":"img/a3.jpg"},
{"id":"69","name":"冯提莫- 大城小爱","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 大城小爱.mp3","images":"img/a4.jpg"},
{"id":"70","name":"冯提莫- 大鱼","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 大鱼.mp3","images":"img/a5.jpg"},
{"id":"71","name":"冯提莫- 天后","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 天后.mp3","images":"img/a1.jpg"},
{"id":"72","name":"冯提莫- 套马杆","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 套马杆.mp3","images":"img/a2.jpg"},
{"id":"73","name":"冯提莫- 好想你","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 好想你.mp3","images":"img/a3.jpg"},
{"id":"74","name":"冯提莫- 如果有来生","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 如果有来生.mp3","images":"img/a4.jpg"},
{"id":"75","name":"冯提莫- 如果没有你","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 如果没有你.mp3","images":"img/a5.jpg"},
{"id":"76","name":"冯提莫- 如果的事","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 如果的事.mp3","images":"img/a1.jpg"},
{"id":"77","name":"冯提莫- 妥协","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 妥协.mp3","images":"img/a2.jpg"},
{"id":"78","name":"冯提莫- 孤独的总和","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 孤独的总和.mp3","images":"img/a3.jpg"},
{"id":"79","name":"冯提莫- 宝贝","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 宝贝.mp3","images":"img/a4.jpg"},
{"id":"80","name":"冯提莫- 容易受伤的女人","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 容易受伤的女人.mp3","images":"img/a5.jpg"},
{"id":"81","name":"冯提莫- 寂寞在唱歌","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 寂寞在唱歌.mp3","images":"img/a1.jpg"},
{"id":"82","name":"冯提莫- 富士山下","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 富士山下.mp3","images":"img/a2.jpg"},
{"id":"83","name":"冯提莫- 小半","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 小半.mp3","images":"img/a3.jpg"},
{"id":"84","name":"冯提莫- 小小","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 小小.mp3","images":"img/a4.jpg"},
{"id":"85","name":"冯提莫- 小幸运","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 小幸运.mp3","images":"img/a5.jpg"},
{"id":"86","name":"冯提莫- 小手拉大手","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 小手拉大手.mp3","images":"img/a1.jpg"},
{"id":"87","name":"冯提莫- 小苹果","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 小苹果.mp3","images":"img/a2.jpg"},
{"id":"88","name":"冯提莫- 小跳蛙","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 小跳蛙.mp3","images":"img/a3.jpg"},
{"id":"89","name":"冯提莫- 小鸡哔哔","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 小鸡哔哔.mp3","images":"img/a4.jpg"},
{"id":"90","name":"冯提莫- 就是我","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 就是我.mp3","images":"img/a5.jpg"},
{"id":"91","name":"冯提莫- 就是爱你","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 就是爱你.mp3","images":"img/a1.jpg"},
{"id":"92","name":"冯提莫- 左边","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 左边.mp3","images":"img/a2.jpg"},
{"id":"93","name":"冯提莫- 平凡之路","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 平凡之路.mp3","images":"img/a3.jpg"},
{"id":"94","name":"冯提莫- 年轮","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 年轮.mp3","images":"img/a4.jpg"},
{"id":"95","name":"冯提莫- 当你","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 当你.mp3","images":"img/a5.jpg"},
{"id":"96","name":"冯提莫- 彩虹","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 彩虹.mp3","images":"img/a1.jpg"},
{"id":"97","name":"冯提莫- 心墙","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 心墙.mp3","images":"img/a2.jpg"},
{"id":"98","name":"冯提莫- 怎么说我不爱你","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 怎么说我不爱你.mp3","images":"img/a3.jpg"},
{"id":"99","name":"冯提莫- 恋爱循环","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 恋爱循环.mp3","images":"img/a4.jpg"},
{"id":"100","name":"冯提莫- 悟空","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 悟空.mp3","images":"img/a5.jpg"},
{"id":"101","name":"冯提莫- 情深深雨蒙蒙","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 情深深雨蒙蒙.mp3","images":"img/a1.jpg"},
{"id":"102","name":"冯提莫- 情非得已","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 情非得已.mp3","images":"img/a2.jpg"},
{"id":"103","name":"冯提莫- 想你的365天","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 想你的365天.mp3","images":"img/a3.jpg"},
{"id":"104","name":"冯提莫- 慢慢","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 慢慢.mp3","images":"img/a4.jpg"},
{"id":"105","name":"冯提莫- 我们的爱","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 我们的爱.mp3","images":"img/a5.jpg"},
{"id":"106","name":"冯提莫- 我在人民广场吃炸鸡","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 我在人民广场吃炸鸡.mp3","images":"img/a1.jpg"},
{"id":"107","name":"冯提莫- 我在人民广场吃着","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 我在人民广场吃着.mp3","images":"img/a2.jpg"},
{"id":"108","name":"冯提莫- 我多么怀念","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 我多么怀念.mp3","images":"img/a3.jpg"},
{"id":"109","name":"冯提莫- 我想对你说baby","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 我想对你说baby.mp3","images":"img/a4.jpg"},
{"id":"110","name":"冯提莫- 我想要飞","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 我想要飞.mp3","images":"img/a5.jpg"},
{"id":"111","name":"冯提莫- 我愿意","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 我愿意.mp3","images":"img/a1.jpg"},
{"id":"112","name":"冯提莫- 我是我的","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 我是我的.mp3","images":"img/a2.jpg"},
{"id":"113","name":"冯提莫- 我是真的爱上你","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 我是真的爱上你.mp3","images":"img/a3.jpg"},
{"id":"114","name":"冯提莫- 我的世界","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 我的世界.mp3","images":"img/a4.jpg"},
{"id":"115","name":"冯提莫- 我的天空","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 我的天空.mp3","images":"img/a5.jpg"},
{"id":"116","name":"冯提莫- 我的快乐","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 我的快乐.mp3","images":"img/a1.jpg"},
{"id":"117","name":"冯提莫- 我的秘密","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 我的秘密.mp3","images":"img/a2.jpg"},
{"id":"118","name":"冯提莫- 我真的受伤了","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 我真的受伤了.mp3","images":"img/a3.jpg"},
{"id":"119","name":"冯提莫- 我要你","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 我要你.mp3","images":"img/a4.jpg"},
{"id":"120","name":"冯提莫- 战争世界","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 战争世界.mp3","images":"img/a5.jpg"},
{"id":"121","name":"冯提莫- 把耳朵叫醒","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 把耳朵叫醒.mp3","images":"img/a1.jpg"},
{"id":"122","name":"冯提莫- 投食歌","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 投食歌.mp3","images":"img/a2.jpg"},
{"id":"123","name":"冯提莫- 指望","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 指望.mp3","images":"img/a3.jpg"},
{"id":"124","name":"冯提莫- 捉泥鳅","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 捉泥鳅.mp3","images":"img/a4.jpg"},
{"id":"125","name":"冯提莫- 握不住的他","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 握不住的他.mp3","images":"img/a5.jpg"},
{"id":"126","name":"冯提莫- 旋木","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 旋木.mp3","images":"img/a1.jpg"},
{"id":"127","name":"冯提莫- 无底洞","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 无底洞.mp3","images":"img/a2.jpg"},
{"id":"128","name":"冯提莫- 时间煮雨","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 时间煮雨.mp3","images":"img/a3.jpg"},
{"id":"129","name":"冯提莫- 明天我要嫁给你啦","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 明天我要嫁给你啦.mp3","images":"img/a4.jpg"},
{"id":"130","name":"冯提莫- 星月神话","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 星月神话.mp3","images":"img/a5.jpg"},
{"id":"131","name":"冯提莫- 星语星愿","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 星语星愿.mp3","images":"img/a1.jpg"},
{"id":"132","name":"冯提莫- 是什么让我遇见这样的你","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 是什么让我遇见这样的你.mp3","images":"img/a2.jpg"},
{"id":"133","name":"冯提莫- 普通disco","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 普通disco.mp3","images":"img/a3.jpg"},
{"id":"134","name":"冯提莫- 晴天","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 晴天.mp3","images":"img/a4.jpg"},
{"id":"135","name":"冯提莫- 暖暖","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 暖暖.mp3","images":"img/a5.jpg"},
{"id":"136","name":"冯提莫- 暗涌","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 暗涌.mp3","images":"img/a1.jpg"},
{"id":"137","name":"冯提莫- 暗香","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 暗香.mp3","images":"img/a2.jpg"},
{"id":"138","name":"冯提莫- 最初的梦想","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 最初的梦想.mp3","images":"img/a3.jpg"},
{"id":"139","name":"冯提莫- 最近","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 最近.mp3","images":"img/a4.jpg"},
{"id":"140","name":"冯提莫- 最重要的决定","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 最重要的决定.mp3","images":"img/a5.jpg"},
{"id":"141","name":"冯提莫- 最长的电影","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 最长的电影.mp3","images":"img/a1.jpg"},
{"id":"142","name":"冯提莫- 月半小夜曲","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 月半小夜曲.mp3","images":"img/a2.jpg"},
{"id":"143","name":"冯提莫- 有可能的夜晚","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 有可能的夜晚.mp3","images":"img/a3.jpg"},
{"id":"144","name":"冯提莫- 有心人","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 有心人.mp3","images":"img/a4.jpg"},
{"id":"145","name":"冯提莫- 杀破狼","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 杀破狼.mp3","images":"img/a5.jpg"},
{"id":"146","name":"冯提莫- 李白","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 李白.mp3","images":"img/a1.jpg"},
{"id":"147","name":"冯提莫- 枫","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 枫.mp3","images":"img/a2.jpg"},
{"id":"148","name":"冯提莫- 柠檬树","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 柠檬树.mp3","images":"img/a3.jpg"},
{"id":"149","name":"冯提莫- 欧若拉","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 欧若拉.mp3","images":"img/a4.jpg"},
{"id":"150","name":"冯提莫- 死性不改","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 死性不改.mp3","images":"img/a5.jpg"},
{"id":"151","name":"冯提莫- 氧气","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 氧气.mp3","images":"img/a1.jpg"},
{"id":"152","name":"冯提莫- 江南","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 江南.mp3","images":"img/a2.jpg"},
{"id":"153","name":"冯提莫- 没那么简单","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 没那么简单.mp3","images":"img/a3.jpg"},
{"id":"154","name":"冯提莫- 泡沫","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 泡沫.mp3","images":"img/a4.jpg"},
{"id":"155","name":"冯提莫- 流年","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 流年.mp3","images":"img/a5.jpg"},
{"id":"156","name":"冯提莫- 海绵宝宝","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 海绵宝宝.mp3","images":"img/a1.jpg"},
{"id":"157","name":"冯提莫- 海阔天空","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 海阔天空.mp3","images":"img/a2.jpg"},
{"id":"158","name":"冯提莫- 满满的都是爱","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 满满的都是爱.mp3","images":"img/a3.jpg"},
{"id":"159","name":"冯提莫- 火烧的寂寞","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 火烧的寂寞.mp3","images":"img/a4.jpg"},
{"id":"160","name":"冯提莫- 热气球","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 热气球.mp3","images":"img/a5.jpg"},
{"id":"161","name":"冯提莫- 煎熬","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 煎熬.mp3","images":"img/a1.jpg"},
{"id":"162","name":"冯提莫- 爱一点","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 爱一点.mp3","images":"img/a2.jpg"},
{"id":"163","name":"冯提莫- 爱一直存在","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 爱一直存在.mp3","images":"img/a3.jpg"},
{"id":"164","name":"冯提莫- 爱上张无忌","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 爱上张无忌.mp3","images":"img/a4.jpg"},
{"id":"165","name":"冯提莫- 爱丫爱丫","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 爱丫爱丫.mp3","images":"img/a5.jpg"},
{"id":"166","name":"冯提莫- 爱你","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 爱你.mp3","images":"img/a1.jpg"},
{"id":"167","name":"冯提莫- 爱囚","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 爱囚.mp3","images":"img/a2.jpg"},
{"id":"168","name":"冯提莫- 爱如潮水","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 爱如潮水.mp3","images":"img/a3.jpg"},
{"id":"169","name":"冯提莫- 爱就一个字","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 爱就一个字.mp3","images":"img/a4.jpg"},
{"id":"170","name":"冯提莫- 爱就爱了","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 爱就爱了.mp3","images":"img/a5.jpg"},
{"id":"171","name":"冯提莫- 爱我还是他","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 爱我还是他.mp3","images":"img/a1.jpg"},
{"id":"172","name":"冯提莫- 爱的主打歌","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 爱的主打歌.mp3","images":"img/a2.jpg"},
{"id":"173","name":"冯提莫- 爱的供养","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 爱的供养.mp3","images":"img/a3.jpg"},
{"id":"174","name":"冯提莫- 爱笑的眼睛","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 爱笑的眼睛.mp3","images":"img/a4.jpg"},
{"id":"175","name":"冯提莫- 独照","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 独照.mp3","images":"img/a5.jpg"},
{"id":"176","name":"冯提莫- 理想情人","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 理想情人.mp3","images":"img/a1.jpg"},
{"id":"177","name":"冯提莫- 电台情歌","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 电台情歌.mp3","images":"img/a2.jpg"},
{"id":"178","name":"冯提莫- 画","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 画.mp3","images":"img/a3.jpg"},
{"id":"179","name":"冯提莫- 盛夏光年","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 盛夏光年.mp3","images":"img/a4.jpg"},
{"id":"180","name":"冯提莫- 真的爱你","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 真的爱你.mp3","images":"img/a5.jpg"},
{"id":"181","name":"冯提莫- 知足","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 知足.mp3","images":"img/a1.jpg"},
{"id":"182","name":"冯提莫- 禁区","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 禁区.mp3","images":"img/a2.jpg"},
{"id":"183","name":"冯提莫- 稻香","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 稻香.mp3","images":"img/a3.jpg"},
{"id":"184","name":"冯提莫- 空城","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 空城.mp3","images":"img/a4.jpg"},
{"id":"185","name":"冯提莫- 童话","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 童话.mp3","images":"img/a5.jpg"},
{"id":"186","name":"冯提莫- 笑忘书","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 笑忘书.mp3","images":"img/a1.jpg"},
{"id":"187","name":"冯提莫- 笔记","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 笔记.mp3","images":"img/a2.jpg"},
{"id":"188","name":"冯提莫- 等下一个天亮","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 等下一个天亮.mp3","images":"img/a3.jpg"},
{"id":"189","name":"冯提莫- 粉红色的回忆","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 粉红色的回忆.mp3","images":"img/a4.jpg"},
{"id":"190","name":"冯提莫- 红日","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 红日.mp3","images":"img/a5.jpg"},
{"id":"191","name":"冯提莫- 红玫瑰","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 红玫瑰.mp3","images":"img/a1.jpg"},
{"id":"192","name":"冯提莫- 红色高跟鞋","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 红色高跟鞋.mp3","images":"img/a2.jpg"},
{"id":"193","name":"冯提莫- 红豆","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 红豆.mp3","images":"img/a3.jpg"},
{"id":"194","name":"冯提莫- 约定","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 约定.mp3","images":"img/a4.jpg"},
{"id":"195","name":"冯提莫- 给我一个理由忘记","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 给我一个理由忘记.mp3","images":"img/a5.jpg"},
{"id":"196","name":"冯提莫- 美丽心情","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 美丽心情.mp3","images":"img/a1.jpg"},
{"id":"197","name":"冯提莫- 美人鱼","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 美人鱼.mp3","images":"img/a2.jpg"},
{"id":"198","name":"冯提莫- 胖妞之歌.avi","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 胖妞之歌.avi","images":"img/a3.jpg"},
{"id":"199","name":"冯提莫- 自然卷（一丢丢）.wav","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 自然卷（一丢丢）.wav","images":"img/a4.jpg"},
{"id":"200","name":"冯提莫- 致青春","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 致青春.mp3","images":"img/a5.jpg"},
{"id":"201","name":"冯提莫- 舞女泪","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 舞女泪.mp3","images":"img/a1.jpg"},
{"id":"202","name":"冯提莫- 苏高飞.avi","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 苏高飞.avi","images":"img/a2.jpg"},
{"id":"203","name":"冯提莫- 茶汤","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 茶汤.mp3","images":"img/a3.jpg"},
{"id":"204","name":"冯提莫- 薄荷与指甲剪","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 薄荷与指甲剪.mp3","images":"img/a4.jpg"},
{"id":"205","name":"冯提莫- 虫儿飞","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 虫儿飞.mp3","images":"img/a5.jpg"},
{"id":"206","name":"冯提莫- 虹之间","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 虹之间.mp3","images":"img/a1.jpg"},
{"id":"207","name":"冯提莫- 袖手旁观","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 袖手旁观.mp3","images":"img/a2.jpg"},
{"id":"208","name":"冯提莫- 记事本","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 记事本.mp3","images":"img/a3.jpg"},
{"id":"209","name":"冯提莫- 说散就散","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 说散就散.mp3","images":"img/a4.jpg"},
{"id":"210","name":"冯提莫- 贝加尔湖畔","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 贝加尔湖畔.mp3","images":"img/a5.jpg"},
{"id":"211","name":"冯提莫- 走在冷风中","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 走在冷风中.mp3","images":"img/a1.jpg"},
{"id":"212","name":"冯提莫- 踮起脚尖爱","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 踮起脚尖爱.mp3","images":"img/a2.jpg"},
{"id":"213","name":"冯提莫- 身骑白马","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 身骑白马.mp3","images":"img/a3.jpg"},
{"id":"214","name":"冯提莫- 遗失的美好","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 遗失的美好.mp3","images":"img/a4.jpg"},
{"id":"215","name":"冯提莫- 避风港","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 避风港.mp3","images":"img/a5.jpg"},
{"id":"216","name":"冯提莫- 那么骄傲","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 那么骄傲.mp3","images":"img/a1.jpg"},
{"id":"217","name":"冯提莫- 那些花儿","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 那些花儿.mp3","images":"img/a2.jpg"},
{"id":"218","name":"冯提莫- 都是夜归人","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 都是夜归人.mp3","images":"img/a3.jpg"},
{"id":"219","name":"冯提莫- 野子","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 野子.mp3","images":"img/a4.jpg"},
{"id":"220","name":"冯提莫- 钟无艳","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 钟无艳.mp3","images":"img/a5.jpg"},
{"id":"221","name":"冯提莫- 阴天","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 阴天.mp3","images":"img/a1.jpg"},
{"id":"222","name":"冯提莫- 雨蝶","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 雨蝶.mp3","images":"img/a2.jpg"},
{"id":"223","name":"冯提莫- 青鸟","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 青鸟.mp3","images":"img/a3.jpg"},
{"id":"224","name":"冯提莫- 靠近一点点","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 靠近一点点.mp3","images":"img/a4.jpg"},
{"id":"225","name":"冯提莫- 马来西亚的查某","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 马来西亚的查某.mp3","images":"img/a5.jpg"},
{"id":"226","name":"冯提莫- 骑士","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 骑士.mp3","images":"img/a1.jpg"},
{"id":"227","name":"冯提莫- 魔鬼中的天使","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 魔鬼中的天使.mp3","images":"img/a2.jpg"},
{"id":"228","name":"冯提莫- 黑色毛衣","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 黑色毛衣.mp3","images":"img/a3.jpg"},
{"id":"229","name":"冯提莫- 默","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/中文MP3合集/冯提莫- 默.mp3","images":"img/a4.jpg"},
{"id":"230","name":"冯提莫- ET","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- ET.mp3","images":"img/a5.jpg"},
{"id":"231","name":"冯提莫- F..kin perfect","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- F..kin perfect.mp3","images":"img/a1.jpg"},
{"id":"232","name":"冯提莫- Firework","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- Firework.mp3","images":"img/a2.jpg"},
{"id":"233","name":"冯提莫- I Could Be The One","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- I Could Be The One.mp3","images":"img/a3.jpg"},
{"id":"234","name":"冯提莫- a new day has come","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- a new day has come.mp3","images":"img/a4.jpg"},
{"id":"235","name":"冯提莫- aliez","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- aliez.mp3","images":"img/a5.jpg"},
{"id":"236","name":"冯提莫- all about that bass（胖妞之歌）","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- all about that bass（胖妞之歌）.mp3","images":"img/a1.jpg"},
{"id":"237","name":"冯提莫- because of you","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- because of you.mp3","images":"img/a2.jpg"},
{"id":"238","name":"冯提莫- boom  clap","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- boom  clap.mp3","images":"img/a3.jpg"},
{"id":"239","name":"冯提莫- boom clap","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- boom clap.mp3","images":"img/a4.jpg"},
{"id":"240","name":"冯提莫- breathless","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- breathless.mp3","images":"img/a5.jpg"},
{"id":"241","name":"冯提莫- butterfly","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- butterfly.mp3","images":"img/a1.jpg"},
{"id":"242","name":"冯提莫- call me maybe","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- call me maybe.mp3","images":"img/a2.jpg"},
{"id":"243","name":"冯提莫- crooked smile","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- crooked smile.mp3","images":"img/a3.jpg"},
{"id":"244","name":"冯提莫- everybody","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- everybody.mp3","images":"img/a4.jpg"},
{"id":"245","name":"冯提莫- fade","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- fade.mp3","images":"img/a5.jpg"},
{"id":"246","name":"冯提莫- faded","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- faded.mp3","images":"img/a1.jpg"},
{"id":"247","name":"冯提莫- far away from home","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- far away from home.mp3","images":"img/a2.jpg"},
{"id":"248","name":"冯提莫- for the first time in forever","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- for the first time in forever.mp3","images":"img/a3.jpg"},
{"id":"249","name":"冯提莫- heartbeats","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- heartbeats.mp3","images":"img/a4.jpg"},
{"id":"250","name":"冯提莫- i knew you were trouble","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- i knew you were trouble.mp3","images":"img/a5.jpg"},
{"id":"251","name":"冯提莫- i love you","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- i love you.mp3","images":"img/a1.jpg"},
{"id":"252","name":"冯提莫- it's only the fairy tale","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- it's only the fairy tale.mp3","images":"img/a2.jpg"},
{"id":"253","name":"冯提莫- let it go","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- let it go.mp3","images":"img/a3.jpg"},
{"id":"254","name":"冯提莫- lf l Ain t Got You","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- lf l Ain t Got You.mp3","images":"img/a4.jpg"},
{"id":"255","name":"冯提莫- lnnocence (1)","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- lnnocence (1).mp3","images":"img/a5.jpg"},
{"id":"256","name":"冯提莫- lnnocence","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- lnnocence.mp3","images":"img/a1.jpg"},
{"id":"257","name":"冯提莫- lost stars","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- lost stars.mp3","images":"img/a2.jpg"},
{"id":"258","name":"冯提莫- love me like you do","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- love me like you do.mp3","images":"img/a3.jpg"},
{"id":"259","name":"冯提莫- mariA","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- maria.mp3","images":"img/a4.jpg"},
{"id":"260","name":"冯提莫- me and my broken heart","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- me and my broken heart.mp3","images":"img/a5.jpg"},
{"id":"261","name":"冯提莫- melody","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- melody.mp3","images":"img/a1.jpg"},
{"id":"262","name":"冯提莫- morning","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- morning.mp3","images":"img/a2.jpg"},
{"id":"263","name":"冯提莫- my dilemmA","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- my dilemma.mp3","images":"img/a3.jpg"},
{"id":"264","name":"冯提莫- new soul","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- new soul.mp3","images":"img/a4.jpg"},
{"id":"265","name":"冯提莫- part of me","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- part of me.mp3","images":"img/a5.jpg"},
{"id":"266","name":"冯提莫- payphone","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- payphone.mp3","images":"img/a1.jpg"},
{"id":"267","name":"冯提莫- price tag","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- price tag.mp3","images":"img/a2.jpg"},
{"id":"268","name":"冯提莫- roar","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- roar.mp3","images":"img/a3.jpg"},
{"id":"269","name":"冯提莫- see you again","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- see you again.mp3","images":"img/a4.jpg"},
{"id":"270","name":"冯提莫- shake it off","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- shake it off.mp3","images":"img/a5.jpg"},
{"id":"271","name":"冯提莫- someone like you","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- someone like you.mp3","images":"img/a1.jpg"},
{"id":"272","name":"冯提莫- stay here forever","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- stay here forever.mp3","images":"img/a2.jpg"},
{"id":"273","name":"冯提莫- stuttering","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- stuttering.mp3","images":"img/a3.jpg"},
{"id":"274","name":"冯提莫- sugar","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- sugar.mp3","images":"img/a4.jpg"},
{"id":"275","name":"冯提莫- take a bow","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- take a bow.mp3","images":"img/a5.jpg"},
{"id":"276","name":"冯提莫- time after time","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- time after time.mp3","images":"img/a1.jpg"},
{"id":"277","name":"冯提莫- try","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- try.mp3","images":"img/a2.jpg"},
{"id":"278","name":"冯提莫- undo it","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- undo it.mp3","images":"img/a3.jpg"},
{"id":"279","name":"冯提莫- waka wakA","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- waka waka.mp3","images":"img/a4.jpg"},
{"id":"280","name":"冯提莫- we are never ever getting back together","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- we are never ever getting back together.mp3","images":"img/a5.jpg"},
{"id":"281","name":"冯提莫- what makes you beaut","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- what makes you beaut.mp3","images":"img/a1.jpg"},
{"id":"282","name":"冯提莫- whataya want from me","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- whataya want from me.mp3","images":"img/a2.jpg"},
{"id":"283","name":"冯提莫- when i was your man","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- when i was your man.mp3","images":"img/a3.jpg"},
{"id":"284","name":"冯提莫- wrecking ball","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- wrecking ball.mp3","images":"img/a4.jpg"},
{"id":"285","name":"冯提莫- you make me wannA","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- you make me wanna.mp3","images":"img/a5.jpg"},
{"id":"286","name":"冯提莫- you raise me up","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/英文歌曲MP3合集/冯提莫- you raise me up.mp3","images":"img/a1.jpg"},
{"id":"287","name":"冯提莫- If you","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/日韩MP3合集/冯提莫- If you.mp3","images":"img/a2.jpg"},
{"id":"288","name":"冯提莫- butterfly","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/日韩MP3合集/冯提莫- butterfly.mp3","images":"img/a3.jpg"},
{"id":"289","name":"冯提莫- what can I do","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/日韩MP3合集/冯提莫- what can I do.mp3","images":"img/a4.jpg"},
{"id":"290","name":"冯提莫- 东京食尸鬼","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/日韩MP3合集/冯提莫- 东京食尸鬼.mp3","images":"img/a5.jpg"},
{"id":"291","name":"冯提莫- 可爱颂","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/日韩MP3合集/冯提莫- 可爱颂.mp3","images":"img/a1.jpg"},
{"id":"292","name":"冯提莫- 星象仪","singer":"","duration":"","src":"http://music.asia.ga/OnedriveTJ/音乐视听/经典音乐大收藏/冯提莫300首/日韩MP3合集/冯提莫- 星象仪.mp3","images":"img/a2.jpg"},

    ]

//formateTime(61)--->01:01


//获取各种标签

    var player = document.querySelector("#player");
    var bz_music = document.querySelector("#bz_music");

    //歌曲信息部分
    var left_photo = document.querySelector("#left_photo");
    var list_title = document.querySelector("#list_title");
    var list_singer = document.querySelector("#list_singer");
    var process_slide = document.querySelector("#process_slide");
    var process = document.querySelector("#process");
    var showHide = document.querySelector("#showHide");
    
    //控制按钮部分
    var time = document.querySelector("#time");
    var　btnPlay　= document.querySelector("#btnPlay");
    var　volume_slide　= document.querySelector("#volume_slide");
    var　volume　= document.querySelector("#volume");
    
    //播放列表部分
    var play_list = document.querySelector("#play_list");
    
    var play_list_area = document.querySelector("#play_list_area");

//动态加载播放列表
    function loadPlayList(){
        //遍历播放列表
        for(var i=0;i<music_list.length;i++){
            //将每个对象，分别存到music中
            var music = music_list[i];
            //创建li标签
            var liTag = document.createElement("li");
            //创建歌曲名span标签
            var spanTitleTag = document.createElement("span");
            //创建时长span标签
            var spanDurationTag = document.createElement("span");
            
            //为ul添加li标签，子节点
            play_list.appendChild(liTag);
            //为li标签，添加子节点
            liTag.appendChild(spanTitleTag);
            liTag.appendChild(spanDurationTag);
            
            //添加内容
            spanTitleTag.innerHTML=music.name;
            spanDurationTag.innerHTML=music.duration;
            
            //添加类名
            spanTitleTag.classList.add("list_title");
            spanDurationTag.classList.add("list_time");
            
            //自定义属性
            //需要用的时候，直接从标签中取值，不需要和后台交互
            liTag.setAttribute("data-index",i);
            
            //当点击每一个li标签的时候
            //重新载入歌曲信息(专辑图片、歌曲路径、歌曲名、歌手名)
            //播放当前点击的音乐
            liTag.addEventListener("click",function(){
                //获取每个li标签的歌曲id
                var index = this.getAttribute("data-index");
//              console.log(index);
                //将歌曲id赋给，全局变量play_index
                play_index = index;
                //调用载入歌曲函数
                loadMusic();
                //播放音乐
                playMusic();
            })
        }
    }
    
//载入歌曲信息
    function loadMusic(){
        var music = music_list[play_index];
        //改变专辑图片
        left_photo.src = music.images;
        //改变歌曲名
        list_title.innerHTML = music.name;
        //改变歌手名
        list_singer.innerHTML = music.singer;
        //改变歌曲路径
        player.src = music.src;
    }
    
//播放,暂停音乐
    btnPlay.addEventListener("click",function(){
        //paused,表示当前音乐是否为暂停状态
        if(player.paused){
            //play(),播放当前音乐
            playMusic();
        }
        else {
            //pause(),暂停当前音乐
            player.pause();
            btnPlay.setAttribute("class","btn_play fa fa-play");
        }
    })

//上一曲
    function backword(){
        if(play_index==0){
            play_index=music_list.length-1;
        }
        else{
            //改变播放序号
            play_index--;
        }
        //重新载入
        loadMusic();
        //播放
        playMusic();   
    }
    
//下一曲
    function forward(){
        if(play_index==music_list.length-1){
            play_index=0;
        }
        else{
            //改变播放序号
            play_index++;
        }
        //重新载入
        loadMusic();
        //播放
        playMusic();   
    }
    
//播放
    function playMusic(){
        player.play();
        btnPlay.setAttribute("class","btn_play fa fa-pause"); 
    }



//时间转换

    function formateTime(time){
        if(time>3600){
            var hour = parseInt(time/3600);
            var minute = parseInt(time%3600/60);
            var second = parseInt(time%3600);
            hour=hour>=10?hour:"0"+hour;
            minute=minute>=10?minute:"0"+minute;
            second=second>=10?second:"0"+second;
            return hour+":"+minute+":"+second;
        }
        else{
            var minute = parseInt(time/60);
            var second = parseInt(time%60);
            minute=minute>=10?minute:"0"+minute;
            second=second>=10?second:"0"+second;
            return minute+":"+second;  
        }

    }
    
//设置定时器
    window.setInterval(function(){
        //currentTime,当前播放的秒数!
//      console.log(player.currentTime);
        time.innerHTML = formateTime(player.currentTime);
        //duration,当前音乐的总时长,秒数!!!
        var percent = player.currentTime/player.duration;
//      console.log(percent);
        process_slide.style.width=percent*100+"%";
    },100)
    
//静音
    function volumeOff(){
        //volume,[0,1]
        player.volume=0;
        volume_slide.style.width=0;
        console.log(player.volume);
    }
    
//最大音 
    function volumeUp(){
        player.volume=1;
        volume_slide.style.width="100%";
        console.log(player.volume);
    }

//通过滑块控制音量大小
    volume.addEventListener("click",function(event){
        //得到当前点击的位置
        var currentVolume = event.offsetX/this.offsetWidth;
        console.log(currentVolume);
        //设置音量
        player.volume=currentVolume;
        volume_slide.style.width = currentVolume*100+"%";
    })

//通过滑块控制音乐进度
    process.addEventListener("click",function(event){
        //计算点击位置的百分比
        var currentValue = event.offsetX/this.offsetWidth;
        
        //因为我们已经设置了定时器,在实时监控我们当前音乐的变化
        //因此,我们通过设置当前播放的音乐时长,影响我们的进度条
        player.currentTime = player.duration*currentValue;
    })

//显示隐藏播放列表
    function showMusicList(){
        //当前已经显示播放列表
        if(flag){
            play_list_area.style.display="none";
            bz_music.style.width="500px";
            showHide.style.color="#666";
            flag=0;
        }
        else {
            play_list_area.style.display="block";
            bz_music.style.width="700px";
            showHide.style.color="#DDD";
            flag=1;
        }
    }


//初始化
    //载入播放列表
    loadPlayList();
    //播放序号
    var play_index=0;
    //初始音量
    player.volume=0.5;
    //初始化显示播放列表
    //当flag为1的时候,表示列表显示(当前状态)
    //当flag为0的时候,表示列表隐藏(当前状态)
    var flag=1;

